﻿using System;
namespace weightPercentCalc
{
    public class UserInput
    {
        public UserInput()
        {
        }
    }
}
