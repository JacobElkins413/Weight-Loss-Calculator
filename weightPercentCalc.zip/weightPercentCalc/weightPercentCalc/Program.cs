﻿using System;

namespace weightPercentCalc
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            while (true)
            {
                //gets name, starting weight and current weight by calling appropriate methods
                string userName = userNameInput("\nWhat is your name?");
                double weight1 = userStartingWeight("Starting weight: ");
                double weight2 = userCurrentWeight("Current weight: ");

                //place to store the end result
                double result;

                while (true)
                {
                    Console.WriteLine("(A)Weight Progress Calculation or (B)Weight Percentage?\n");
                    ConsoleKeyInfo info1 = Console.ReadKey(); //obtains the next character the user presses
                    string choice = info1.Key.ToString(); //stores the character pressed in a string 

                    //switch statement to validate the user pressing A or B
                    //when option is chosen, an if statement will determine whether or not to tell the user if they lost or gained weight
                    switch (choice.ToUpper())
                    {
                        case "A":
                            result = totalWeightLoss(weight1, weight2);
                            if (weight1 > weight2)
                            {
                                Console.WriteLine("\n\n" + userName + "'s total weight loss is " + result + "lb\n");
                            }else
                            {
                                Console.WriteLine("\n\n" + userName + "'s total weight gain is " + result + "lb\n");
                            }
                            break;
                        case "B":
                            result = weightLossPercent(weight1, weight2);
                            if (weight1 > weight2)
                            {
                                Console.WriteLine("\n\n" + userName + "'s weight loss percentage is " + result + "%\n");
                            }else
                            {
                                Console.WriteLine("\n\n" + userName + "'s weight gain percentage is " + result + "%\n");
                            }
                            break;
                        default:
                            Console.WriteLine("\nPlease choose A or B");
                            continue;
                    }
                    break;
                }

                //when the user chooses an appropriate option they will be shown their weight progress or percentage
                //then aked if they want to calcuate another using a switch statment to validate their answer.

                Console.WriteLine("Would you like to calculate another? Y/N\n");
                ConsoleKeyInfo info2 = Console.ReadKey();
                string yesNo = info2.Key.ToString();

                switch (yesNo.ToUpper())
                {
                    case "Y":
                        continue;
                    case "N":
                        break;
                    default:
                        Console.WriteLine("Please choose Y or N");
                        continue;
                }
            }
        }

        private static string userNameInput(string userName)
        {
            //creates variable for name to be store in based on user input
            Console.WriteLine(userName);
            string name = Console.ReadLine();


            return name;

        }

        private static double userStartingWeight(string input)
        {
            //variable made to store starting weight
            //while loop to validate input

            double value1;

            while (true)
            {
                Console.WriteLine(input);
                string weightInputStart = Console.ReadLine();
                if (Double.TryParse(weightInputStart, out value1))
                {
                    return value1;
                }
                else
                {
                    Console.WriteLine("Invalid weight");
                    continue;
                }
            }

        }

        private static double userCurrentWeight(string input)
        {
            //variable made to store current weight
            //while loop to validate input

            double value2;

            while (true)
            {
                Console.WriteLine(input);
                string weightInputCurrent = Console.ReadLine();
                if (Double.TryParse(weightInputCurrent, out value2))
                {
                    return value2;
                }
                else
                {
                    Console.WriteLine("Invalid weight");
                    continue;
                }
            }
        }

        private static double totalWeightLoss(double weight1, double weight2)
        {
            //if user wants to know their weight loss an if statement will loop through to determine if they lost or gained 
            //weight and make the proper calculation 

            if (weight1 > weight2)
            {
                double weightDown = weight1 - weight2;
                return weightDown;
            }else
            {
                double weightUp = weight2 - weight1;
                return weightUp;
            }

        }

        private static double weightLossPercent(double weight1, double weight2)
        {
            //if the user chooses weight loss percent, an if statement will make the proper calculation to deteremine if they gained or lost weight

            if (weight1 > weight2)
            {
                double weightLoss = weight1 - weight2;
                double operation = weightLoss * 100;
                double result = operation / weight1;
                return Math.Round(result, 2);
            }else
            {
                double weightLoss = weight2 - weight1;
                double operation = weightLoss * 100;
                double result = operation / weight2;
                return Math.Round(result, 2);
            }
        }
    }
}
